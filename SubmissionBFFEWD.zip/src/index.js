import global from './scripts/global';
import indonesia from './scripts/indonesia';
import cardglobal from './scripts/cardglobal';
import cardindo from './scripts/cardindo';

cardindo();
cardglobal();
global();
indonesia();
